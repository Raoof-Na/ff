# TG String Session
Generate Pyrogram String Session Using this bot.

## Configs:
- BOT_TOKEN
  - Telegram Bot Token from [here](https://telegram.dog/BotFather).

## Deploy Now:
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Dev3yad/session-pyrogram-bot)
